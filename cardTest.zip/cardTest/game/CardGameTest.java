package game;

import org.junit.Test;
import static org.junit.Assert.*;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Queue;

public class CardGameTest {


    private static Object invokePrivateMethod(String methodName, Class<?>[] parameterTypes, Object[] args) throws Exception {
        Method method = CardGame.class.getDeclaredMethod(methodName, parameterTypes);
        method.setAccessible(true);
        return method.invoke(null, args);
    }

    // Helper method to create a temporary pack file
    private File createTempPackFile(int numOfPlayers) throws IOException {
        File tempFile = File.createTempFile("test_pack", ".txt");
        tempFile.deleteOnExit();

        try (FileWriter writer = new FileWriter(tempFile)) {
            // Write numOfPlayers * 8 unique numbers
            for (int i = 1; i <= numOfPlayers * 8; i++) {
                writer.write(i + "\n");
            }
        }

        return tempFile;
    }

    @Test
    public void testInitPlayerNum_ValidInput() throws Exception {
        // Simulate user input of 4 players
        System.setIn(new ByteArrayInputStream("4\n".getBytes()));
        
        Object result = invokePrivateMethod("initPlayerNum", new Class<?>[0], new Object[0]);
        
        assertEquals(4, result);
    }

    @Test
    public void testInitPlayerNum_InvalidInput() throws Exception {
        // Simulate various invalid inputs followed by a valid input
        String[] invalidInputs = {"zero\n", "-1\n", "abc\n", "4\n"};
        
        // Combine invalid inputs
        StringBuilder combinedInput = new StringBuilder();
        for (String input : invalidInputs) {
            combinedInput.append(input);
        }
        
        System.setIn(new ByteArrayInputStream(combinedInput.toString().getBytes()));
        
    }


    @Test
    public void testLoadPack_ValidPack() throws Exception {
        // Create a temporary pack file with valid number of cards
        int numOfPlayers = 4;
        File tempFile = createTempPackFile(numOfPlayers);
        
        // Simulate user input with the temp file path
        System.setIn(new ByteArrayInputStream(tempFile.getAbsolutePath().getBytes()));
        
        Queue<Card> pack = (Queue<Card>) invokePrivateMethod("loadPack", new Class<?>[] {int.class}, new Object[] {numOfPlayers});
        
        assertEquals(numOfPlayers * 8, pack.size());
    }

    @Test
    public void testLoadPack_InvalidPackSize() throws Exception {
        // Create a temporary pack file with incorrect number of cards
        int numOfPlayers = 4;
        File tempFile = File.createTempFile("invalid_pack", ".txt");
        tempFile.deleteOnExit();

        try (FileWriter writer = new FileWriter(tempFile)) {
            // Write fewer cards than required
            for (int i = 1; i <= numOfPlayers * 4; i++) {
                writer.write(i + "\n");
            }
        }
        
        // This will require multiple inputs to handle the invalid pack
        String inputs = tempFile.getAbsolutePath() + "\n" + createTempPackFile(numOfPlayers).getAbsolutePath() + "\n";
        System.setIn(new ByteArrayInputStream(inputs.getBytes()));
        
        Queue<Card> pack = (Queue<Card>) invokePrivateMethod("loadPack", new Class<?>[] {int.class}, new Object[] {numOfPlayers});
        
        assertEquals(numOfPlayers * 8, pack.size());
    }

    @Test
    public void testInitializePlayers() throws Exception {
        // Create a valid pack
        int numOfPlayers = 4;
        Queue<Card> pack = new LinkedList<>();
        for (int i = 1; i <= numOfPlayers * 8; i++) {
            pack.add(new Card(i));
        }
        
        ArrayList<Player> players = (ArrayList<Player>) invokePrivateMethod(
            "initializePlayers", 
            new Class<?>[] {int.class, Queue.class}, 
            new Object[] {numOfPlayers, pack}
        );
        
        assertEquals(numOfPlayers, players.size());
        
        // Check that each player has 4 cards
        for (Player player : players) {
            assertEquals(4, player.getHand().size());
        }
    }

    @Test
    public void testInitializeDecks() throws Exception {
        // Create a valid pack
        int numOfPlayers = 4;
        Queue<Card> pack = new LinkedList<>();
        for (int i = 1; i <= numOfPlayers * 8; i++) {
            pack.add(new Card(i));
        }
        
        // Create dummy player
        ArrayList <Player> players = (ArrayList<Player>) invokePrivateMethod(
            "initializePlayers",
            new Class<?> [] {int.class, Queue.class},
            new Object[] {numOfPlayers, pack}
        );


        ArrayList<Deck> decks = (ArrayList<Deck>) invokePrivateMethod(
            "initializeDecks", 
            new Class<?>[] {Queue.class, ArrayList.class}, 
            new Object[] {pack, players}
        );
        
        assertEquals(numOfPlayers, decks.size());
        
        // Check that decks have been distributed cards
        for (Deck deck : decks) {
            assertEquals(4, deck.getCards().size());
        }
    }

    @Test
    public void testAssignDecks() throws Exception {
        // Create players
        int numOfPlayers = 4;
        ArrayList<Player> players = new ArrayList<>();
        for (int i = 0; i < numOfPlayers; i++) {
            players.add(new Player(i, i));
        }
        
        // Create decks
        ArrayList<Deck> decks = new ArrayList<>();
        for (int i = 0; i < numOfPlayers; i++) {
            decks.add(new Deck(i));
        }
        
        // Invoke the method
        invokePrivateMethod(
            "assignDecks", 
            new Class<?>[] {ArrayList.class, ArrayList.class}, 
            new Object[] {players, decks}
        );
        
        // Verify deck assignments
        for (int i = 0; i < players.size(); i++) {
            Player player = players.get(i);
            
            if (i == players.size() - 1) {
                // Last player
                assertEquals(decks.get(players.size()-1), player.getDrawDeck());
                assertEquals(decks.get(0), player.getDiscardDeck());
            } else {
                // Other players
                assertEquals(decks.get(i), player.getDrawDeck());
                assertEquals(decks.get(i+1), player.getDiscardDeck());
            }
        }
    }

   
}




package game;

import java.io.FileWriter;
import java.io.IOException;
import java.util.LinkedList;
import java.util.Queue;
import java.util.concurrent.BrokenBarrierException;
import java.util.concurrent.CyclicBarrier;

public class Player implements Runnable {
    private int id;
    private final Queue<Card> hand;
    private int preferredDenomination;
    private Deck drawDeck;
    private Deck discardDeck;
    private boolean winStatus = false;
    private static final Object gameLock = new Object();
    private static volatile boolean gameOver = false;
    private static int winningPlayerId;
    public static int totalPlayers;
    private static CyclicBarrier barrier;

    public Player(int id, int preferredDenomination) {
        this.id = id;
        this.preferredDenomination = preferredDenomination;
        this.hand = new LinkedList<>();
    }

    public Player(int id, int preferredDenomination, Deck drawDeck, Deck discardDeck) {
        this(id, preferredDenomination);
        this.drawDeck = drawDeck;
        this.discardDeck = discardDeck;
    }

    public synchronized void addCard(Card card) {
        if(card != null){
            hand.add(card);
        }
    }

    public Queue<Card> getHand() {
        return hand;
    }

    public Deck getDrawDeck() {
        return drawDeck;
    }

    public Deck getDiscardDeck() {
        return discardDeck;
    }

    public void setDrawDeck(Deck drawDeck) {
        this.drawDeck = drawDeck;
    }

    public void setDiscardDeck(Deck discardDeck) {
        this.discardDeck = discardDeck;
    }

    public void setWinStatus(boolean winStatus) {
        this.winStatus = winStatus;
    }

    public boolean getWinStatus() {
        return winStatus;
    }

    public int getId() {
        return id;
    }

    
    public static void setBarrier(CyclicBarrier barrier) {
        Player.barrier = barrier;
    }

    public static void setGameOver(boolean gameOver) {
        Player.gameOver = gameOver;
    }

    public void setPreferredDenomination (int preferredDenomination) {
        this.preferredDenomination = preferredDenomination;
    }
    public int getPreferredDenomination() {
        return preferredDenomination;
    }

    public static int getWinningPlayerId() {
        return winningPlayerId;
    }

    public static void setWinningPlayerId(int winningPlayerId) {
        Player.winningPlayerId = winningPlayerId;
    }

    private synchronized boolean hasWinningHand() {
        if (hand.isEmpty()) return false;
        int firstValue = hand.peek().getValue();
        for (Card card : hand) {
            if (card.getValue() != firstValue) return false;
        }
        return true;
    }

    private synchronized Card chooseDiscardCard() {
        if(!gameOver){
            for (Card card : hand) {
                if (card.getValue() != preferredDenomination) {
                    hand.remove(card);
                    return card;
                }
            }
        // If no non-preferred card is found, discard the first card
            return hand.poll();
        }
    return null;
    }

    // Helper method for other writing methods
    private void writeToFile(String content) {
        try (FileWriter writer = new FileWriter("OutputFiles/player" + id + "_output.txt", true)) {
            writer.write(content + System.lineSeparator());
        } catch (IOException e) {
            System.err.println("Error writing to file for player " + id + ": " + e.getMessage());
        }
    }

    private synchronized void writeGameActionsToFile(Card cardDrawn, Card cardDiscarded) {
        if (!this.winStatus && cardDrawn != null && cardDiscarded != null) {
            writeToFile(String.format("player %d draws a %d from deck %d", id, cardDrawn.getValue(), drawDeck.getDeckNum()));
            writeToFile(String.format("player %d discards a %d to deck %d", id, cardDiscarded.getValue(), discardDeck.getDeckNum()));
            writeToFile(String.format("player %d current hand is %s", id, hand));
        }
    }

    private synchronized void writeEndGameLinesToFile() {
        if (gameOver) {
            if (winStatus) {
                writeToFile(String.format("player %d wins", id));
                writeToFile(String.format("player %d exits", id));
                writeToFile(String.format("player %d final hand: %s", id, hand));
            } else {
                writeToFile(String.format("player %d has informed player %d that player %d has won", winningPlayerId, id, winningPlayerId));
                writeToFile(String.format("player %d exits", id));
                writeToFile(String.format("player %d hand: %s", id, hand));
            }
        }
    }

    private void writeInitialHandToFile() {
        writeToFile(String.format("player %d initial hand %s", id, hand));
    }

    
    
    @Override
    public void run() {
        try {
            // Write initial hand to file
            writeInitialHandToFile();
    
            // Check for an immediate win condition before starting
            synchronized (gameLock) {
                if (hasWinningHand()) {
                    gameOver = true;
                    winningPlayerId = id;
                    winStatus = true;
                    System.out.println("Player " + id + " wins!");
                }
            }

            // Ensure all players know about the game being over
            barrier.await();

            if (gameOver) {
                // All threads write their final state
                writeEndGameLinesToFile();
                drawDeck.writeFinalDeckToFiles();
                discardDeck.writeFinalDeckToFiles();
            }
    
            // If no immediate win, proceed with the game
            if (!gameOver) {                
                while (!gameOver) {
                    // Draw a card
                    Card drawnCard = drawDeck.drawCard();
                    if (drawnCard != null) {
                        hand.add(drawnCard);
                    }
        
                    // Discard a card
                    Card discardedCard = chooseDiscardCard();
                    if (discardedCard != null) {
                        discardDeck.addCard(discardedCard);
                    }
        
                    // Log actions to file
                    writeGameActionsToFile(drawnCard, discardedCard);
        
                    // Check if this player has won
                    synchronized (gameLock) {
                        if (hasWinningHand()) {
                            gameOver = true;
                            winningPlayerId = id;
                            winStatus = true;
                            System.out.println("Player " + id + " wins!");
                        }
                    }
        
                    // Synchronize with other players
                    barrier.await();
                }
    
                // Write final state when game is over
                writeEndGameLinesToFile();
                drawDeck.writeFinalDeckToFiles();
                discardDeck.writeFinalDeckToFiles();
            }
    
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            System.out.println("Player " + id + " was interrupted.");
        } catch (BrokenBarrierException e) {
            e.printStackTrace();
        }
    }
}
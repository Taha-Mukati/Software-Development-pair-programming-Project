package game;
import java.util.Queue;
import java.io.FileWriter;
import java.io.IOException;
import java.util.LinkedList;


public class Deck {
	
	private final int deckNum;
	Queue<Card> cards =	new LinkedList<>();

	public Deck (int deckNum) {
		this.deckNum = deckNum;
	}

	public Deck (int deckNum, Queue<Card> cards) {
		this.deckNum = deckNum;
		this.cards = cards;
	}
	public int getDeckNum() {
		return deckNum;
	}
	
	public Queue<Card> getCards() {
		return cards;
	}
	public synchronized void addCard (Card card) {
		cards.add(card);
	}

	public synchronized Card drawCard () {
		return cards.poll();
	}
	public synchronized boolean isEmpty() {
		return cards.isEmpty();
	}
	
	public synchronized void writeFinalDeckToFiles() {
        try {
            String name = String.format("deck%d_output.txt", deckNum);
            FileWriter myWriter = new FileWriter("OutputFiles/" + name + "/");
            myWriter.write(String.format("deck%d contents: %s", deckNum, cards));
            myWriter.close();
        } catch (IOException e) {
            System.out.println("An error occurred.");
            e.printStackTrace();
        }
    }
}
package game;

import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;

import java.io.File;
import java.lang.reflect.Method;
import java.util.concurrent.CyclicBarrier;

public class PlayerTest {
    private Player player;
    private Deck mockDrawDeck;
    private Deck mockDiscardDeck;
    private Card mockCard;

    @Before
    public void setUp() {
        // Create mock Decks
        mockDrawDeck = mock(Deck.class);
        mockDiscardDeck = mock(Deck.class);

        // Create mock Card
        mockCard = mock(Card.class);
        when(mockCard.getValue()).thenReturn(5);  // Assuming card value is 5 for testing

        // Initialize the Player with mocked dependencies
        player = new Player(1, 5, mockDrawDeck, mockDiscardDeck);
    }

    @Test
    public void testPlayerConstructorWithoutDecks() {
        Player playerWithoutDecks = new Player(2, 7);
        assertEquals(2, playerWithoutDecks.getId());
        assertEquals(7, playerWithoutDecks.getPreferredDenomination());
        assertNotNull(playerWithoutDecks.getHand());
    }

    @Test
    public void testAddCard() {
        // Add a card to the player's hand
        player.addCard(mockCard);

        // Verify the card is added to the player's hand
        assertTrue(player.getHand().contains(mockCard));
    }

    @Test
    public void testSetAndGetWinStatus() {
        // Set winStatus to true
        player.setWinStatus(true);
        assertTrue(player.getWinStatus());
        
        // Set winStatus to false
        player.setWinStatus(false);
        assertFalse(player.getWinStatus());
    }

    @Test
    public void testGetId() {
        // Verify player ID is correctly set
        assertEquals(1, player.getId());
    }

    @Test
    public void testPreferredDenomination() {
        // Initially set in constructor, should be 5
        assertEquals(5, player.getPreferredDenomination());
        
        // Set new preferred denomination
        player.setPreferredDenomination(8);
        assertEquals(8, player.getPreferredDenomination());
    }

    @Test
    public void testGetWinningPlayerId() {
        // Set winning player ID
        Player.setWinningPlayerId(1);

        // Verify the winning player ID is returned correctly
        assertEquals(1, Player.getWinningPlayerId());
    }

    @Test
    public void testSetDrawDeck() {
        // Change the drawDeck
        Deck newDeck = mock(Deck.class);
        player.setDrawDeck(newDeck);
        assertEquals(newDeck, player.getDrawDeck());
    }

    @Test
    public void testSetDiscardDeck() {
        // Change the discardDeck
        Deck newDeck = mock(Deck.class);
        player.setDiscardDeck(newDeck);
        assertEquals(newDeck, player.getDiscardDeck());
    }

    @Test
    public void testSetWinningPlayerId() {
        // Set the winning player ID
        Player.setWinningPlayerId(1);
        assertEquals(1, Player.getWinningPlayerId());
        
        Player.setWinningPlayerId(2);
        assertEquals(2, Player.getWinningPlayerId());
    }


    @Test
    public void testHasWinningHand_withWinningHand() {
        // Add cards to the player's hand that have the same value
        when(mockCard.getValue()).thenReturn(5);
        player.addCard(mockCard);
        player.addCard(mockCard);  // Two cards with the same value should form a winning hand
        try {
            Method method = Player.class.getDeclaredMethod("hasWinningHand");
            method.setAccessible(true);
            boolean result = (boolean) method.invoke(player);

            // Verify that the player has a winning hand
            assertTrue(result);
        } catch (Exception e) {
            e.printStackTrace();
            fail("Reflection failed: " + e.getMessage());
        }
    }

    @Test
    public void testHasWinningHand_withNonWinningHand() {
        // Add cards to the player's hand with different values
        when(mockCard.getValue()).thenReturn(5);
        player.addCard(mockCard);

        Card anotherCard = mock(Card.class);
        when(anotherCard.getValue()).thenReturn(10);
        player.addCard(anotherCard);

        try {
            Method method = Player.class.getDeclaredMethod("hasWinningHand");
            method.setAccessible(true);
            boolean result = (boolean) method.invoke(player);

            // Verify that the player does not have a winning hand
            assertFalse(result);
        } catch (Exception e) {
            e.printStackTrace();
            fail("Reflection failed: " + e.getMessage());
        }
    }

    @Test
    public void testChooseDiscardCard() {
        // Add cards to the player's hand
        when(mockCard.getValue()).thenReturn(5);
        player.addCard(mockCard);
        Player.setGameOver(false);

        try {
            Method method = Player.class.getDeclaredMethod("chooseDiscardCard");
            method.setAccessible(true);

            // Verify that the correct card is discarded
            Card discardedCard = (Card) method.invoke(player);
            assertEquals(mockCard, discardedCard);
        } catch (Exception e) {
            e.printStackTrace();
            fail("Reflection failed: " + e.getMessage());
        }
    }

    @Test
    public void testChooseDiscardCard_nonPreferredCard() {
        // Add cards to the player's hand
        when(mockCard.getValue()).thenReturn(5);
        player.addCard(mockCard);

        Card otherCard = mock(Card.class);
        when(otherCard.getValue()).thenReturn(10);
        player.addCard(otherCard);

        // Set the player's preferred denomination to 5 (should discard the non-preferred card)
        player.setPreferredDenomination(5);

        try {
            Method method = Player.class.getDeclaredMethod("chooseDiscardCard");
            method.setAccessible(true);

            // Verify that the non-preferred card is discarded
            Card discardedCard = (Card) method.invoke(player);
            assertEquals(otherCard, discardedCard);
        } catch (Exception e) {
            e.printStackTrace();
            fail("Reflection failed: " + e.getMessage());
        }
    }

    @Test
    public void testRun_withWinningHand() throws InterruptedException {
        // Set up the player's hand and mock behavior for the test
        when(mockCard.getValue()).thenReturn(5);
        player.addCard(mockCard);
        player.addCard(mockCard); // Two cards with the same value should form a winning hand
        Player.setBarrier(new CyclicBarrier(1));
        File folder = new File("OutputFiles");
        folder.mkdir();

        // Simulate the run method logic
        Thread playerThread = new Thread(player);
        playerThread.start();

        // Let the player thread run for a bit
        Thread.sleep(200);

        try {
            Method method = Player.class.getDeclaredMethod("hasWinningHand");
            method.setAccessible(true);
            boolean result = (boolean) method.invoke(player);

            // Verify that the player has won
            assertTrue(result);
            assertEquals(1, Player.getWinningPlayerId());
        } catch (Exception e) {
            e.printStackTrace();
            fail("Reflection failed: " + e.getMessage());
        }
    }

    @Test
    public void testRun_withoutWinningHand() throws InterruptedException {
        // Set up the player's hand and mock behavior for the test
        when(mockCard.getValue()).thenReturn(5);
        player.addCard(mockCard);
        Card otherCard = mock(Card.class);
        when(otherCard.getValue()).thenReturn(10);
        player.addCard(otherCard);

        // Simulate the run method logic
        Thread playerThread = new Thread(player);
        playerThread.start();

        // Let the player thread run for a bit
        Thread.sleep(200);

        // Verify that the player has not won
        assertFalse(player.getWinStatus());
    }
}

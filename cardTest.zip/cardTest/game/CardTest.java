package game;

import org.junit.Test;
import static org.junit.Assert.*;

public class CardTest {
    
    @Test
    public void testCreateCard() {
        Card card = new Card(2);
        assertEquals("Card value should be ", 2, card.getValue());
        assertEquals("Card toString should be ", "2", card.toString());
    }
    
    @Test
    public void testGetValue() {
        Card card = new Card(2);
        assertEquals("Card value should be ", 2, card.getValue());
    }

    @Test
    public void testToString() {
        Card card = new Card(2);
        assertEquals("Card toString should be ", "2", card.toString());
    }
    

}


package game;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Scanner;
import java.util.concurrent.CyclicBarrier;
import java.io.File;
import java.io.FileNotFoundException;

public class CardGame {
    
    private static int initPlayerNum() {
        
        Scanner myObj = new Scanner(System.in);  
        System.out.println("Enter the Number of players:");

        // Using user prompt as number of players
        String players = myObj.nextLine();
        try {
            int numOfPlayers = Integer.parseInt(players);
            return numOfPlayers;
        } catch (NumberFormatException e) {
            System.out.println("Invalid input. Please try again.");
            return initPlayerNum();
        }
    }

    private static Queue<Card> loadPack(int numOfPlayers) {
        LinkedList<Card> listPack = new LinkedList<>();
        Scanner userInput = new Scanner(System.in);
    
        while (true) {
            boolean invalidFlag = false; // Flag for checking negative integers
            System.out.println("Please enter location of pack to load:");
    
            String filename = userInput.nextLine();
            try {
                File inputFile = new File(filename);
                Scanner file = new Scanner(inputFile);
    
                // Read card numbers from file
                while (file.hasNextInt()) {
                    int number = file.nextInt();
                    if (number < 0) {
                        invalidFlag = true;
                    }
                    Card card = new Card(number);
                    listPack.add(card);
                }
                file.close();

                // If the pack contains negative integers
                if (invalidFlag) {
                    System.out.println("The pack contains some negative integers. Please try again.");
                    listPack.clear(); // Clear list to avoid duplicating entries
                    continue;
                }
                
                // Validate pack size
                Queue<Card> pack = new LinkedList<>(listPack);
                int packSize = pack.size();

                // If the pack does not match the number of players, or have some invalid inputs, e.g. character
                if (numOfPlayers * 8 != packSize) {
                    System.out.println("The pack is invalid. Please try again.");
                    listPack.clear(); // Clear list to avoid duplicating entries
                    continue;
                }
    
                return pack;
    
            } catch (FileNotFoundException e) {
                System.out.println("File not found. Please enter a valid file path.");
            }
        }
    }
    private static ArrayList<Player> initializePlayers(int numOfPlayers, Queue<Card> pack) {
        ArrayList<Player> players = new ArrayList<>();
        for (int i = 1; i <= numOfPlayers; i++) { // Player numbers start at 1
            players.add(new Player(i, i));
        }
        int k = 0;
        for (int j = 0; j < (players.size() * 4); j++) {
            Card card = pack.poll();
            Player player = players.get(k);
            player.addCard(card);
            k = (k + 1) % players.size();
        }
    
        return players;
    }
    
    private static ArrayList<Deck> initializeDecks(Queue<Card> pack, ArrayList<Player> players) {
        ArrayList<Deck> decks = new ArrayList<>();
        for (int i = 1; i <= players.size(); i++) { // Deck numbers start at 1
            decks.add(new Deck(i));
        }
        int k = 0;
        while (!pack.isEmpty()) {
            Card card = pack.poll();
            Deck deck = decks.get(k);
            deck.addCard(card);
            k = (k + 1) % decks.size();
        }
    
        return decks;
    }
    
    // Assign each deck for each player as a discard deck or a draw deck
    private static void assignDecks(ArrayList<Player> players, ArrayList<Deck> decks) {
        for (int i = 0; i < players.size(); i++) { // Loop starts at 0
            Player player = players.get(i);
            Deck drawDeck = decks.get(i);
            Deck discardDeck = decks.get((i + 1) % decks.size());
            player.setDrawDeck(drawDeck);
            player.setDiscardDeck(discardDeck);
        }
    }

    private static void deleteFolderContents(File folder) {
        File[] files = folder.listFiles();
        if (files != null) {
            for (File file : files) {
                if (file.isDirectory()) {
                    deleteFolderContents(file);
                }
                file.delete();
            }
        }
    }
    
    
    public static void main (String[] args) {
        
        String folderPath = "OutputFiles";
        File folder = new File(folderPath);

        // Create a output folder, delete the contents if the folder exists.
        if (!folder.exists()) {
            folder.mkdir(); 
        } else {
            deleteFolderContents(folder);
        }
        int numOfPlayers = initPlayerNum();
        Player.totalPlayers = numOfPlayers;
        Queue<Card> pack = loadPack(numOfPlayers);
        ArrayList<Player> players = initializePlayers(numOfPlayers, pack);
        ArrayList<Deck> decks = initializeDecks(pack, players);
        assignDecks(players, decks);
        Thread[] playerThreads = new Thread[numOfPlayers];
        CyclicBarrier barrier = new CyclicBarrier(numOfPlayers);
        Player.setBarrier(barrier);
        for (int i = 0; i < numOfPlayers; i++) {
            playerThreads[i] = new Thread(players.get(i));
            playerThreads[i].start();
        }
        
        for (Thread thread : playerThreads) {
            try {
                thread.join();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
}

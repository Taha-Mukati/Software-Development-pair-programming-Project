package game;

import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;

import java.util.Queue;
import java.util.LinkedList;

public class DeckTest {

    private Deck deck;
    private Card mockCard;

    // Setup method to initialize the test data before each test
    @Before
    public void setUp() {
        // Create a mock Card object
        mockCard = mock(Card.class);
        // Initialize the deck with a specific deck number
        deck = new Deck(1);  // A deck with deckNum = 1
    }

    @Test
    public void testDeckConstructor() {
        // Test that the constructor correctly initializes the deckNum
        assertEquals(1, deck.getDeckNum());
        
        // Test that the deck starts with an empty queue of cards
        assertTrue(deck.getCards().isEmpty());
    }

    @Test
    public void testDeckConstructorWithCards() {
        // Create a new deck with predefined cards
        Queue<Card> initialCards = new LinkedList<>();
        initialCards.add(mockCard);
        Deck deckWithCards = new Deck(2, initialCards);
        
        // Test that the deck is initialized correctly with the given cards
        assertEquals(2, deckWithCards.getDeckNum());
        assertEquals(1, deckWithCards.getCards().size());
        assertTrue(deckWithCards.getCards().contains(mockCard));
    }

    @Test
    public void testAddCard() {
        // Add a mock card to the deck
        deck.addCard(mockCard);
        
        // Verify that the card was added
        assertFalse(deck.getCards().isEmpty());
        assertTrue(deck.getCards().contains(mockCard));
    }

    @Test
    public void testDrawCard() {
        // Add a card to the deck
        deck.addCard(mockCard);
        
        // Draw a card from the deck
        Card drawnCard = deck.drawCard();
        
        // Verify that the card drawn is the same as the card added
        assertEquals(mockCard, drawnCard);
        
        // Verify that the deck is now empty
        assertTrue(deck.getCards().isEmpty());
    }

    @Test
    public void testIsEmpty() {
        // Test that the deck is initially empty
        assertTrue(deck.isEmpty());
        
        // Add a card to the deck
        deck.addCard(mockCard);
        
        // Verify that the deck is not empty after adding a card
        assertFalse(deck.isEmpty());
        
        // Draw the card from the deck
        deck.drawCard();
        
        // Verify that the deck is empty after drawing the card
        assertTrue(deck.isEmpty());
    }

    @Test
    public void testDrawCardFromEmptyDeck() {
        // Try to draw a card from an empty deck
        Card drawnCard = deck.drawCard();
        
        // Verify that drawing from an empty deck returns null
        assertNull(drawnCard);
    }
}
## Prerequisites

Before running the test suite, ensure the following tools and dependencies are properly set up:
1. Java Development Kit (JDK):
   - Ensure you have JDK 23 or later installed on your system and have the java PATH setup correctly.
   - To verify installation, run:
```
    java -version
```
2. Extract this zip file.

The dependencies are already included in the zip file.

## Running the Tests

The test can be run by:
```
    java game/TestRunner
```
at the root directory of the extracted folder.

Results would be printed on the terminal, either printing True if all tests pass, or printing the failure ones and printing False.
